package com.touchracermobile

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.abs

class MainActivity : Activity(), SensorEventListener {
    companion object {
        private const val PORT = 8765
        private const val BG = 0xFF080D13.toInt()
        private const val PANEL = 0xFF121B24.toInt()
        private const val MUTED = 0xFF91A0AE.toInt()
        private const val GREEN = 0xFF18C78E.toInt()
        private const val RED = 0xFFE34D5B.toInt()
        private const val BLUE = 0xFF267CB8.toInt()
        private const val WHITE = 0xFFF3F6F8.toInt()
    }

    private enum class Role { HOME, CONTROLLER, RECEIVER }
    private var role = Role.HOME
    private val io = Executors.newSingleThreadScheduledExecutor()
    private var sender: ScheduledFuture<*>? = null
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var writer: BufferedWriter? = null
    private var sensorManager: SensorManager? = null
    private var rotationSensor: Sensor? = null
    private var calibrated = false
    private var neutralRoll = 0f
    private var currentRoll = 0f
    @Volatile private var steering = 0f
    @Volatile private var throttle = 0f
    @Volatile private var brake = 0f
    @Volatile private var gearUpSeq = 0
    @Volatile private var gearDownSeq = 0
    @Volatile private var drs = false
    @Volatile private var ers = false

    private var statusView: TextView? = null
    private var steerValueView: TextView? = null
    private var ipInput: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showHome()
    }

    private fun makeRoot(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(12), dp(18), dp(12))
        setBackgroundColor(BG)
    }.also { setContentView(it) }

    private fun label(value: String, size: Float = 14f, color: Int = WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = rounded(PANEL, 16)
    }

    private fun button(value: String, color: Int): Button = Button(this).apply {
        text = value
        textSize = 14f
        isAllCaps = false
        setTextColor(WHITE)
        background = rounded(color, 12)
        stateListAnimator = null
        minHeight = dp(52)
        setPadding(dp(8), dp(4), dp(8), dp(4))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addWeighted(parent: LinearLayout, child: View, weight: Float = 1f) {
        parent.addView(child, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
            setMargins(dp(5), dp(4), dp(5), dp(4))
        })
    }

    private fun showHome() {
        role = Role.HOME
        val root = makeRoot()
        root.addView(label("TOUCH RACER", 28f, GREEN, true), LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(label("MOBILE F1 CONTROLLER  ·  PHONE  ↔  TABLET", 13f, MUTED, true), LinearLayout.LayoutParams(-1, dp(36)))
        val choices = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val phone = button("PHONE  /  CONTROLLER", GREEN)
        val tablet = button("TABLET  /  RECEIVER", BLUE)
        choices.addView(phone, LinearLayout.LayoutParams(0, dp(110), 1f).apply { setMargins(dp(8), dp(12), dp(8), dp(8)) })
        choices.addView(tablet, LinearLayout.LayoutParams(0, dp(110), 1f).apply { setMargins(dp(8), dp(12), dp(8), dp(8)) })
        root.addView(choices)
        root.addView(label("Connect both devices to the same private Wi‑Fi / hotspot", 12f, MUTED))
        phone.setOnClickListener { showController() }
        tablet.setOnClickListener { showReceiver() }
    }

    private fun showController() {
        role = Role.CONTROLLER
        val root = makeRoot()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("TR  /  PHONE CONTROLLER", 19f, GREEN, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        ipInput = EditText(this).apply {
            hint = "Tablet IP address"
            setHintTextColor(MUTED)
            setTextColor(WHITE)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            singleLine = true
            background = rounded(PANEL, 10)
            setPadding(dp(12), 0, dp(12), 0)
        }
        header.addView(ipInput, LinearLayout.LayoutParams(dp(180), dp(44)))
        val connect = button("CONNECT", GREEN)
        header.addView(connect, LinearLayout.LayoutParams(dp(112), dp(44)).apply { setMargins(dp(8), 0, 0, 0) })
        root.addView(header)
        statusView = label("Enter the tablet IP, then connect.", 12f, MUTED)
        root.addView(statusView, LinearLayout.LayoutParams(-1, dp(28)))

        val dashboard = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 4f }
        val steeringPanel = panel()
        steeringPanel.addView(label("STEERING", 13f, MUTED, true))
        steerValueView = label("0.00", 34f, WHITE, true)
        steeringPanel.addView(steerValueView)
        steeringPanel.addView(label("TILT PHONE LEFT / RIGHT", 10f, MUTED))
        val calibrate = button("CALIBRATE LEVEL", BLUE)
        steeringPanel.addView(calibrate, LinearLayout.LayoutParams(-1, dp(46)).apply { setMargins(0, dp(12), 0, 0) })
        calibrate.setOnClickListener {
            neutralRoll = currentRoll
            calibrated = true
            setStatus("Neutral position set. Tilt gently to steer.")
        }
        addWeighted(dashboard, steeringPanel, 1.2f)

        val pedalPanel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; background = rounded(PANEL, 16); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val gas = button("THROTTLE\nHOLD", GREEN)
        val stop = button("BRAKE\nHOLD", RED)
        pedalPanel.addView(gas, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
        pedalPanel.addView(stop, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(5), dp(5), dp(5), dp(5)) })
        gas.setOnTouchListener { _, event ->
            throttle = when (event.action) { MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> 1f; else -> 0f }
            true
        }
        stop.setOnTouchListener { _, event ->
            brake = when (event.action) { MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> 1f; else -> 0f }
            true
        }
        addWeighted(dashboard, pedalPanel, 1.8f)

        val functionPanel = panel()
        val up = button("GEAR  +", BLUE)
        val down = button("GEAR  −", BLUE)
        val drsButton = button("DRS  OFF", 0xFF34414D.toInt())
        val ersButton = button("ERS  OFF", 0xFF34414D.toInt())
        functionPanel.addView(up, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(3), 0, dp(3)) })
        functionPanel.addView(down, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(3), 0, dp(3)) })
        functionPanel.addView(drsButton, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(3), 0, dp(3)) })
        functionPanel.addView(ersButton, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(3), 0, dp(3)) })
        up.setOnClickListener { gearUpSeq++ }
        down.setOnClickListener { gearDownSeq++ }
        drsButton.setOnClickListener { drs = !drs; drsButton.text = if (drs) "DRS  ON" else "DRS  OFF"; drsButton.background = rounded(if (drs) GREEN else 0xFF34414D.toInt(), 12) }
        ersButton.setOnClickListener { ers = !ers; ersButton.text = if (ers) "ERS  ON" else "ERS  OFF"; ersButton.background = rounded(if (ers) BLUE else 0xFF34414D.toInt(), 12) }
        addWeighted(dashboard, functionPanel, 1f)
        root.addView(dashboard, LinearLayout.LayoutParams(-1, 0, 1f))

        connect.setOnClickListener { connectToTablet(ipInput?.text?.toString()?.trim().orEmpty()) }
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotationSensor == null) setStatus("This phone has no compatible rotation sensor.")
        else sensorManager?.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun showReceiver() {
        role = Role.RECEIVER
        val root = makeRoot()
        root.addView(label("TR  /  TABLET RECEIVER", 22f, BLUE, true), LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(label("1. Start the receiver   2. Enable the accessibility bridge   3. Open Monoposto", 12f, MUTED))
        statusView = label("Tablet IP: ${wifiIpAddress()}\nTCP port: $PORT", 18f, WHITE, true)
        root.addView(statusView, LinearLayout.LayoutParams(-1, dp(76)))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val start = button("START RECEIVER", GREEN)
        val accessibility = button("ACCESSIBILITY SETTINGS", BLUE)
        actions.addView(start, LinearLayout.LayoutParams(0, dp(72), 1f).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        actions.addView(accessibility, LinearLayout.LayoutParams(0, dp(72), 1f).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        root.addView(actions)
        root.addView(label("Keep this app running, keep the screen awake, and use a private hotspot only.", 12f, MUTED))
        start.setOnClickListener { startReceiver() }
        accessibility.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    private fun connectToTablet(host: String) {
        if (host.isBlank()) { setStatus("Please enter the tablet IP address."); return }
        setStatus("Connecting to $host:$PORT …")
        io.execute {
            try {
                try { clientSocket?.close() } catch (_: Exception) { }
                val socket = Socket()
                socket.tcpNoDelay = true
                socket.connect(java.net.InetSocketAddress(host, PORT), 4000)
                clientSocket = socket
                writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))
                sender?.cancel(false)
                sender = io.scheduleAtFixedRate({
                    try {
                        val line = buildPacket()
                        synchronized(this) { writer?.apply { write(line); newLine(); flush() } }
                    } catch (e: Exception) {
                        runOnUiThread { setStatus("Connection lost: ${e.message ?: "socket error"}") }
                        try { socket.close() } catch (_: Exception) { }
                        sender?.cancel(false)
                    }
                }, 0, 50, TimeUnit.MILLISECONDS)
                runOnUiThread { setStatus("CONNECTED  ·  tilt to steer, hold pedals") }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Could not connect: ${e.message ?: "check IP and Wi‑Fi"}") }
            }
        }
    }

    private fun buildPacket(): String = org.json.JSONObject().apply {
        put("steer", steering.toDouble())
        put("throttle", throttle.toDouble())
        put("brake", brake.toDouble())
        put("gearUpSeq", gearUpSeq)
        put("gearDownSeq", gearDownSeq)
        put("drs", drs)
        put("ers", ers)
    }.toString()

    private fun startReceiver() {
        if (serverSocket != null) { setStatus("Receiver is already running on port $PORT."); return }
        setStatus("Starting receiver…")
        io.execute {
            try {
                val server = ServerSocket(PORT)
                server.reuseAddress = true
                serverSocket = server
                runOnUiThread { setStatus("LISTENING  ·  ${wifiIpAddress()}  ·  port $PORT") }
                while (!server.isClosed) {
                    val client = server.accept()
                    clientSocket = client
                    client.tcpNoDelay = true
                    runOnUiThread { setStatus("PHONE CONNECTED  ·  waiting for controls") }
                    try {
                        val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
                        while (!client.isClosed) {
                            val line = reader.readLine() ?: break
                            try { ControlStateStore.latest = ControlState.parse(line) } catch (_: Exception) { }
                        }
                    } catch (_: Exception) {
                    } finally {
                        ControlStateStore.latest = null
                        try { client.close() } catch (_: Exception) { }
                        runOnUiThread { if (!isFinishing) setStatus("PHONE DISCONNECTED  ·  listening on port $PORT") }
                    }
                }
            } catch (e: Exception) {
                if (serverSocket?.isClosed != true) runOnUiThread { setStatus("Receiver error: ${e.message}") }
            }
        }
    }

    private fun wifiIpAddress(): String {
        return try {
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val raw = wifi.connectionInfo.ipAddress
            if (raw == 0) "Not connected to Wi‑Fi" else listOf(raw and 255, raw shr 8 and 255, raw shr 16 and 255, raw shr 24 and 255).joinToString(".")
        } catch (_: Exception) { "Open Wi‑Fi details to find the IP" }
    }

    private fun setStatus(message: String) {
        statusView?.text = message
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (role != Role.CONTROLLER) return
        val matrix = FloatArray(9)
        val orientation = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(matrix, event.values)
        val remapped = FloatArray(9)
        val rotation = windowManager.defaultDisplay.rotation
        when (rotation) {
            android.view.Surface.ROTATION_90 -> SensorManager.remapCoordinateSystem(matrix, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, remapped)
            android.view.Surface.ROTATION_180 -> SensorManager.remapCoordinateSystem(matrix, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_MINUS_Y, remapped)
            android.view.Surface.ROTATION_270 -> SensorManager.remapCoordinateSystem(matrix, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, remapped)
            else -> matrix.copyInto(remapped)
        }
        SensorManager.getOrientation(remapped, orientation)
        currentRoll = orientation[2]
        if (calibrated) {
            var delta = currentRoll - neutralRoll
            if (delta > PI) delta -= (2 * PI).toFloat()
            if (delta < -PI) delta += (2 * PI).toFloat()
            var normalized = (delta * 1.7f).coerceIn(-1f, 1f)
            if (abs(normalized) < 0.035f) normalized = 0f
            steering = steering * 0.72f + normalized * 0.28f
            steerValueView?.text = String.format(java.util.Locale.US, "%+.2f", steering)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onResume() {
        super.onResume()
        if (role == Role.CONTROLLER) rotationSensor?.let { sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        sensorManager?.unregisterListener(this)
        super.onPause()
    }

    override fun onDestroy() {
        sender?.cancel(true)
        try { writer?.close() } catch (_: Exception) { }
        try { clientSocket?.close() } catch (_: Exception) { }
        try { serverSocket?.close() } catch (_: Exception) { }
        io.shutdownNow()
        super.onDestroy()
    }
}
