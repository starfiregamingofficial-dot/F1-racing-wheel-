package com.touchracermobile

import org.json.JSONObject

/** Latest controller state received by the tablet. */
data class ControlState(
    val steer: Float = 0f,
    val throttle: Float = 0f,
    val brake: Float = 0f,
    val gearUpSeq: Int = 0,
    val gearDownSeq: Int = 0,
    val drs: Boolean = false,
    val ers: Boolean = false,
    val autoGear: Boolean = false,
    val receivedAt: Long = System.currentTimeMillis()
) {
    companion object {
        fun parse(line: String): ControlState {
            val json = JSONObject(line)
            return ControlState(
                steer = json.optDouble("steer", 0.0).toFloat().coerceIn(-1f, 1f),
                throttle = json.optDouble("throttle", 0.0).toFloat().coerceIn(0f, 1f),
                brake = json.optDouble("brake", 0.0).toFloat().coerceIn(0f, 1f),
                gearUpSeq = json.optInt("gearUpSeq", 0),
                gearDownSeq = json.optInt("gearDownSeq", 0),
                drs = json.optBoolean("drs", false),
                ers = json.optBoolean("ers", false),
                autoGear = json.optBoolean("autoGear", false)
            )
        }
    }
}

object ControlStateStore {
    @Volatile var latest: ControlState? = null
    @Volatile var packetCount: Long = 0
    @Volatile var dispatchStatus: String = "Accessibility service not tested"
    @Volatile var dispatchAccepted: Long = 0
    @Volatile var dispatchCompleted: Long = 0
    @Volatile var dispatchCancelled: Long = 0
}
