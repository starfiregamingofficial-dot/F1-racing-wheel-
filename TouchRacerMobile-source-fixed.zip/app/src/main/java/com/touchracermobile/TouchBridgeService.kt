package com.touchracermobile

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * Converts controller packets into touchscreen contacts on the tablet.
 * Each control contact is continued from one short gesture segment to the next,
 * allowing steering + throttle + brake to remain separate simultaneous pointers.
 */
class TouchBridgeService : AccessibilityService() {
    companion object {
        /**
         * Default relative coordinates for a landscape game HUD.
         * Adjust these after checking Monoposto's actual on-screen control layout.
         * Values are fractions of the tablet's usable screen (0.0 to 1.0).
         */
        private const val STEER_CENTER_X = 0.20f
        private const val STEER_RANGE_X = 0.12f
        private const val STEER_Y = 0.82f
        private const val THROTTLE_X = 0.88f
        private const val BRAKE_X = 0.74f
        private const val PEDAL_Y = 0.86f
        private const val GEAR_UP_X = 0.84f
        private const val GEAR_DOWN_X = 0.74f
        private const val GEAR_Y = 0.16f
        private const val DRS_X = 0.94f
        private const val DRS_Y = 0.16f
        private const val ERS_X = 0.94f
        private const val ERS_Y = 0.27f
        private const val SEGMENT_MS = 80L
        private const val PACKET_TIMEOUT_MS = 500L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val activeStrokes = mutableMapOf<String, GestureDescription.StrokeDescription>()
    private val lastPoints = mutableMapOf<String, Pair<Float, Float>>()
    private var dispatchInProgress = false
    private var lastGearUpSeq = 0
    private var lastGearDownSeq = 0
    private var lastDrs: Boolean? = null
    private var lastErs: Boolean? = null
    private var pumpStarted = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (!pumpStarted) {
            pumpStarted = true
            handler.post(pump)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = releaseAll()

    private val pump = object : Runnable {
        override fun run() {
            if (!dispatchInProgress) dispatchNextSegment()
            handler.postDelayed(this, 25L)
        }
    }

    private fun dispatchNextSegment() {
        val packet = ControlStateStore.latest
        val state = packet?.takeIf { System.currentTimeMillis() - it.receivedAt <= PACKET_TIMEOUT_MS }
        val screenW = resources.displayMetrics.widthPixels.toFloat()
        val screenH = resources.displayMetrics.heightPixels.toFloat()

        val desired = linkedMapOf<String, Pair<Float, Float>>()
        if (state != null) {
            val steerX = (STEER_CENTER_X + state.steer * STEER_RANGE_X).coerceIn(0.04f, 0.48f)
            desired["steer"] = Pair(screenW * steerX, screenH * STEER_Y)
            if (state.throttle > 0.15f) desired["throttle"] = Pair(screenW * THROTTLE_X, screenH * PEDAL_Y)
            if (state.brake > 0.15f) desired["brake"] = Pair(screenW * BRAKE_X, screenH * PEDAL_Y)
        }

        val taps = mutableListOf<Pair<Float, Float>>()
        if (state != null) {
            if (state.gearUpSeq != lastGearUpSeq) taps.add(Pair(screenW * GEAR_UP_X, screenH * GEAR_Y))
            if (state.gearDownSeq != lastGearDownSeq) taps.add(Pair(screenW * GEAR_DOWN_X, screenH * GEAR_Y))
            if (lastDrs != null && state.drs != lastDrs) taps.add(Pair(screenW * DRS_X, screenH * DRS_Y))
            if (lastErs != null && state.ers != lastErs) taps.add(Pair(screenW * ERS_X, screenH * ERS_Y))
            lastGearUpSeq = state.gearUpSeq
            lastGearDownSeq = state.gearDownSeq
            lastDrs = state.drs
            lastErs = state.ers
        }

        if (desired.isEmpty() && taps.isEmpty() && activeStrokes.isEmpty()) return

        val builder = GestureDescription.Builder()
        val nextStrokes = mutableMapOf<String, GestureDescription.StrokeDescription>()
        val nextPoints = mutableMapOf<String, Pair<Float, Float>>()
        var strokeCount = 0

        // Continue all active controls or start a new contact where needed.
        for ((name, point) in desired) {
            val previous = activeStrokes[name]
            val path = Path()
            val stroke = if (previous != null) {
                val from = lastPoints[name] ?: point
                path.moveTo(from.first, from.second)
                path.lineTo(point.first, point.second)
                previous.continueStroke(path, 0L, SEGMENT_MS, true)
            } else {
                path.moveTo(point.first, point.second)
                path.lineTo(point.first + 0.2f, point.second + 0.2f)
                GestureDescription.StrokeDescription(path, 0L, SEGMENT_MS, true)
            }
            builder.addStroke(stroke)
            nextStrokes[name] = stroke
            nextPoints[name] = point
            strokeCount++
        }

        // End contacts that were held in the previous segment but are no longer requested.
        for ((name, previous) in activeStrokes) {
            if (desired.containsKey(name)) continue
            val point = lastPoints[name] ?: continue
            val path = Path().apply {
                moveTo(point.first, point.second)
                lineTo(point.first + 0.2f, point.second + 0.2f)
            }
            builder.addStroke(previous.continueStroke(path, 0L, SEGMENT_MS, false))
            strokeCount++
        }

        // Gear and DRS/ERS are momentary taps, added to the same multi-touch gesture.
        for (point in taps) {
            val path = Path().apply {
                moveTo(point.first, point.second)
                lineTo(point.first + 0.2f, point.second + 0.2f)
            }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0L, 65L, false))
            strokeCount++
        }

        if (strokeCount == 0) return
        dispatchInProgress = true
        val accepted = dispatchGesture(builder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                activeStrokes.clear()
                activeStrokes.putAll(nextStrokes)
                lastPoints.clear()
                lastPoints.putAll(nextPoints)
                dispatchInProgress = false
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                // Another system/game gesture can cancel accessibility input. Reset cleanly.
                activeStrokes.clear()
                lastPoints.clear()
                dispatchInProgress = false
            }
        }, handler)
        if (!accepted) {
            activeStrokes.clear()
            lastPoints.clear()
            dispatchInProgress = false
        }
    }

    private fun releaseAll() {
        ControlStateStore.latest = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releaseAll()
        super.onDestroy()
    }
}
