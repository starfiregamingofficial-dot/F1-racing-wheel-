package com.touchracermobile

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.abs

class MainActivity : Activity(), SensorEventListener {
    companion object {
        private const val PORT = 8765
        private const val BG = 0xFF080A0E.toInt()
        private const val PANEL = 0xFF151A21.toInt()
        private const val MUTED = 0xFF9AA5B1.toInt()
        private const val GREEN = 0xFF20D66B.toInt()
        private const val RED = 0xFFFF334B.toInt()
        private const val BLUE = 0xFF3287FF.toInt()
        private const val WHITE = 0xFFF4F6F8.toInt()
        private const val DARK = 0xFF242B34.toInt()
    }

    private enum class Role { HOME, CONTROLLER, RECEIVER }
    private var role = Role.HOME
    private val io = Executors.newSingleThreadScheduledExecutor()
    private var sender: ScheduledFuture<*>? = null
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var writer: BufferedWriter? = null
    private var sensorManager: SensorManager? = null
    private var rotationSensor: Sensor? = null
    private var calibrated = false
    private var neutralRoll = 0f
    private var currentRoll = 0f
    @Volatile private var steering = 0f
    @Volatile private var throttle = 0f
    @Volatile private var brake = 0f
    @Volatile private var gearUpSeq = 0
    @Volatile private var gearDownSeq = 0
    @Volatile private var drs = false
    @Volatile private var ers = false
    @Volatile private var autoGear = false

    private var statusView: TextView? = null
    private var receiverDebugView: TextView? = null
    @Volatile private var receivedPacketCount = 0L
    private var steerValueView: TextView? = null
    private var ipInput: EditText? = null
    private var gearModeButton: Button? = null
    private var extrasRow: LinearLayout? = null
    private val extras = mutableListOf<Pair<String, String>>()
    private val prefs by lazy { getSharedPreferences("touch_racer", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        autoGear = prefs.getBoolean("auto_gear", false)
        loadExtras()
        showHome()
    }

    private fun loadExtras() {
        extras.clear()
        val raw = prefs.getString("extra_buttons", "") ?: ""
        raw.split("|").filter { it.contains(":") }.forEach {
            val p = it.split(":", limit = 2)
            if (p.size == 2 && p[1] in listOf("DRS", "ERS", "GEAR_UP", "GEAR_DOWN")) extras.add(p[0] to p[1])
        }
    }

    private fun saveExtras() {
        prefs.edit().putString("extra_buttons", extras.joinToString("|") { "${it.first}:${it.second}" }).apply()
    }

    private fun makeRoot(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(10), dp(7), dp(10), dp(7))
        setBackgroundColor(BG)
    }.also { setContentView(it) }

    private fun label(value: String, size: Float = 14f, color: Int = WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun rounded(color: Int, radius: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(2), stroke)
    }

    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        setPadding(dp(7), dp(6), dp(7), dp(6)); background = rounded(PANEL, 15)
    }

    private fun button(value: String, color: Int, stroke: Int = 0): Button = Button(this).apply {
        text = value; textSize = 14f; isAllCaps = false; setTextColor(WHITE)
        background = rounded(color, 13, stroke); stateListAnimator = null
        minHeight = dp(44); setPadding(dp(6), dp(3), dp(6), dp(3))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addWeighted(parent: LinearLayout, child: View, weight: Float, margin: Int = 4) {
        parent.addView(child, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
            setMargins(dp(margin), dp(3), dp(margin), dp(3))
        })
    }

    private fun showHome() {
        role = Role.HOME
        val root = makeRoot()
        root.addView(label("◉  TOUCH RACER", 29f, RED, true), LinearLayout.LayoutParams(-1, dp(62)))
        root.addView(label("MOBILE RACING CONTROLLER  ·  PHONE  ↔  TABLET", 13f, MUTED, true), LinearLayout.LayoutParams(-1, dp(34)))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val phone = button("PHONE  /  CONTROLLER", GREEN)
        val tablet = button("TABLET  /  RECEIVER", BLUE)
        row.addView(phone, LinearLayout.LayoutParams(0, dp(110), 1f).apply { setMargins(dp(8), dp(12), dp(8), dp(8)) })
        row.addView(tablet, LinearLayout.LayoutParams(0, dp(110), 1f).apply { setMargins(dp(8), dp(12), dp(8), dp(8)) })
        root.addView(row)
        root.addView(label("Connect both devices to the same private Wi‑Fi / hotspot", 12f, MUTED))
        phone.setOnClickListener { showController() }
        tablet.setOnClickListener { showReceiver() }
    }

    private fun showController() {
        role = Role.CONTROLLER
        val root = makeRoot()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("TR  /  RACE CONTROL", 18f, RED, true), LinearLayout.LayoutParams(0, dp(40), 1f))
        ipInput = EditText(this).apply {
            hint = "Tablet IP"; setHintTextColor(MUTED); setTextColor(WHITE); textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            isSingleLine = true; background = rounded(PANEL, 10); setPadding(dp(10), 0, dp(10), 0)
        }
        header.addView(ipInput, LinearLayout.LayoutParams(dp(145), dp(40)))
        val connect = button("CONNECT", GREEN)
        header.addView(connect, LinearLayout.LayoutParams(dp(98), dp(40)).apply { setMargins(dp(6), 0, 0, 0) })
        root.addView(header)

        statusView = label("Enter tablet IP and connect  ·  same Wi‑Fi required", 11f, MUTED)
        root.addView(statusView, LinearLayout.LayoutParams(-1, dp(23)))

        val dashboard = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 10f }

        // Full-height left brake pedal.
        val brakeButton = button("BRAKE\n\n▼\nHOLD", RED, 0xFFFF7180.toInt()).apply { textSize = 23f; typeface = Typeface.DEFAULT_BOLD }
        brakeButton.setOnTouchListener { _, e ->
            brake = when (e.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> if (e.x >= 0 && e.y >= 0) 1f else 0f
                else -> 0f
            }; true
        }
        addWeighted(dashboard, brakeButton, 3.0f, 3)

        // Compact centre cockpit.
        val centre = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(PANEL, 15); setPadding(dp(5), dp(4), dp(5), dp(4)) }
        val steerTitle = label("GYRO STEERING", 12f, MUTED, true)
        centre.addView(steerTitle, LinearLayout.LayoutParams(-1, dp(22)))
        steerValueView = label("0.00", 28f, WHITE, true)
        centre.addView(steerValueView, LinearLayout.LayoutParams(-1, dp(43)))
        val calibrate = button("CALIBRATE", BLUE)
        centre.addView(calibrate, LinearLayout.LayoutParams(-1, dp(37)).apply { setMargins(dp(3), 0, dp(3), dp(4)) })
        calibrate.setOnClickListener { neutralRoll = currentRoll; calibrated = true; setStatus("Steering centred. Tilt gently left/right.") }

        val gearRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        gearModeButton = button(if (autoGear) "AUTO GEAR  ON" else "MANUAL GEAR", if (autoGear) GREEN else DARK)
        gearRow.addView(gearModeButton, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        val up = button("▲  UP", BLUE)
        val down = button("▼  DOWN", BLUE)
        gearRow.addView(up, LinearLayout.LayoutParams(0, dp(40), 0.7f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        gearRow.addView(down, LinearLayout.LayoutParams(0, dp(40), 0.7f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        centre.addView(gearRow)
        gearModeButton?.setOnClickListener {
            autoGear = !autoGear
            prefs.edit().putBoolean("auto_gear", autoGear).apply()
            updateGearMode()
        }
        up.setOnClickListener { if (!autoGear) gearUpSeq++ }
        down.setOnClickListener { if (!autoGear) gearDownSeq++ }

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val drsButton = button(if (drs) "DRS ON" else "DRS OFF", if (drs) GREEN else DARK)
        val ersButton = button(if (ers) "ERS ON" else "ERS OFF", if (ers) BLUE else DARK)
        actionRow.addView(drsButton, LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        actionRow.addView(ersButton, LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        centre.addView(actionRow)
        drsButton.setOnClickListener { drs = !drs; drsButton.text = if (drs) "DRS ON" else "DRS OFF"; drsButton.background = rounded(if (drs) GREEN else DARK, 12) }
        ersButton.setOnClickListener { ers = !ers; ersButton.text = if (ers) "ERS ON" else "ERS OFF"; ersButton.background = rounded(if (ers) BLUE else DARK, 12) }

        extrasRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        centre.addView(extrasRow, LinearLayout.LayoutParams(-1, dp(40)))
        val addExtra = button("+ ADD BUTTON", 0xFF3A2630.toInt(), RED)
        centre.addView(addExtra, LinearLayout.LayoutParams(-1, dp(34)).apply { setMargins(dp(2), dp(1), dp(2), 0) })
        addExtra.setOnClickListener { showAddExtraDialog() }
        addWeighted(dashboard, centre, 4.0f, 3)

        // Full-height right throttle pedal.
        val throttleButton = button("THROTTLE\n\n▲\nHOLD", GREEN, 0xFF72F69A.toInt()).apply { textSize = 23f; typeface = Typeface.DEFAULT_BOLD }
        throttleButton.setOnTouchListener { _, e ->
            throttle = when (e.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> if (e.x >= 0 && e.y >= 0) 1f else 0f
                else -> 0f
            }; true
        }
        addWeighted(dashboard, throttleButton, 3.0f, 3)
        root.addView(dashboard, LinearLayout.LayoutParams(-1, 0, 1f))

        connect.setOnClickListener { connectToTablet(ipInput?.text?.toString()?.trim().orEmpty()) }
        renderExtras()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotationSensor == null) setStatus("No compatible gyro sensor found.")
        else sensorManager?.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun updateGearMode() {
        gearModeButton?.text = if (autoGear) "AUTO GEAR  ON" else "MANUAL GEAR"
        gearModeButton?.background = rounded(if (autoGear) GREEN else DARK, 12)
        setStatus(if (autoGear) "Automatic gear mode selected. Manual paddles disabled." else "Manual gear mode selected. Use UP/DOWN paddles.")
    }

    private fun showAddExtraDialog() {
        val actions = arrayOf("DRS", "ERS", "GEAR UP", "GEAR DOWN")
        AlertDialog.Builder(this).setTitle("Add a quick button")
            .setItems(actions) { _, which ->
                val action = listOf("DRS", "ERS", "GEAR_UP", "GEAR_DOWN")[which]
                val edit = EditText(this).apply { hint = "Button label"; setText(actions[which]); selectAll() }
                AlertDialog.Builder(this).setTitle("Name this button").setView(edit)
                    .setPositiveButton("Add") { _, _ ->
                        val name = edit.text.toString().trim().take(10).ifBlank { actions[which] }
                        if (extras.size < 3) { extras.add(name to action); saveExtras(); renderExtras() }
                        else setStatus("Maximum 3 extra quick buttons.")
                    }.setNegativeButton("Cancel", null).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun renderExtras() {
        val row = extrasRow ?: return
        row.removeAllViews()
        extras.forEachIndexed { index, item ->
            val b = button(item.first, 0xFF303943.toInt())
            row.addView(b, LinearLayout.LayoutParams(0, dp(36), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            b.setOnClickListener {
                when (item.second) {
                    "DRS" -> { drs = !drs; drsButtonPulse() }
                    "ERS" -> { ers = !ers; ersButtonPulse() }
                    "GEAR_UP" -> if (!autoGear) gearUpSeq++
                    "GEAR_DOWN" -> if (!autoGear) gearDownSeq++
                }
                setStatus("${item.first} activated  ·  long-press to remove")
            }
            b.setOnLongClickListener {
                extras.removeAt(index); saveExtras(); renderExtras(); true
            }
        }
    }

    private fun drsButtonPulse() = Unit
    private fun ersButtonPulse() = Unit

    private fun showReceiver() {
        role = Role.RECEIVER
        val root = makeRoot()
        root.addView(label("TR  /  TABLET RECEIVER", 22f, BLUE, true), LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(label("1. Start receiver   2. Enable accessibility bridge   3. Open Monoposto", 12f, MUTED))
        statusView = label("Tablet IP: ${wifiIpAddress()}\nTCP port: $PORT", 18f, WHITE, true)
        root.addView(statusView, LinearLayout.LayoutParams(-1, dp(76)))
        receiverDebugView = label("Waiting for control packets…", 15f, WHITE, true)
        root.addView(receiverDebugView, LinearLayout.LayoutParams(-1, dp(100)))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val start = button("START RECEIVER", GREEN)
        val accessibility = button("ACCESSIBILITY SETTINGS", BLUE)
        actions.addView(start, LinearLayout.LayoutParams(0, dp(72), 1f).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        actions.addView(accessibility, LinearLayout.LayoutParams(0, dp(72), 1f).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        root.addView(actions)
        root.addView(label("Keep this app running and use a private Wi‑Fi / hotspot.", 12f, MUTED))
        start.setOnClickListener { startReceiver() }
        accessibility.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    private fun connectToTablet(host: String) {
        if (host.isBlank()) { setStatus("Enter the tablet IP address."); return }
        setStatus("Connecting to $host:$PORT …")
        io.execute {
            try {
                try { clientSocket?.close() } catch (_: Exception) { }
                val socket = Socket(); socket.tcpNoDelay = true
                socket.connect(java.net.InetSocketAddress(host, PORT), 4000)
                clientSocket = socket
                writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))
                sender?.cancel(false)
                sender = io.scheduleAtFixedRate({
                    try {
                        val line = buildPacket()
                        synchronized(this) { writer?.apply { write(line); newLine(); flush() } }
                    } catch (e: Exception) {
                        runOnUiThread { setStatus("Connection lost: ${e.message ?: "socket error"}") }
                        try { socket.close() } catch (_: Exception) { }
                        sender?.cancel(false)
                    }
                }, 0, 50, TimeUnit.MILLISECONDS)
                runOnUiThread { setStatus("CONNECTED  ·  gyro steering and pedals live") }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Could not connect: ${e.message ?: "check IP / Wi‑Fi"}") }
            }
        }
    }

    private fun buildPacket(): String = org.json.JSONObject().apply {
        put("steer", steering.toDouble()); put("throttle", throttle.toDouble()); put("brake", brake.toDouble())
        put("gearUpSeq", gearUpSeq); put("gearDownSeq", gearDownSeq)
        put("drs", drs); put("ers", ers); put("autoGear", autoGear)
    }.toString()

    private fun startReceiver() {
        if (serverSocket != null) { setStatus("Receiver already running on port $PORT."); return }
        setStatus("Starting receiver…")
        io.execute {
            try {
                val server = ServerSocket(PORT); server.reuseAddress = true; serverSocket = server
                runOnUiThread { setStatus("LISTENING  ·  ${wifiIpAddress()}  ·  port $PORT") }
                while (!server.isClosed) {
                    val client = server.accept(); clientSocket = client; client.tcpNoDelay = true
                    runOnUiThread { setStatus("PHONE CONNECTED  ·  receiving controls") }
                    try {
                        val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
                        while (!client.isClosed) {
                            val line = reader.readLine() ?: break
                            try {
                                val state = ControlState.parse(line)
                                ControlStateStore.latest = state
                                receivedPacketCount++
                                runOnUiThread {
                                    receiverDebugView?.text = String.format(
                                        java.util.Locale.US,
                                        "PACKETS: %d\\nSTEER: %.2f   THROTTLE: %.2f\\nBRAKE: %.2f   GEAR: %s",
                                        receivedPacketCount, state.steer, state.throttle, state.brake,
                                        if (state.autoGear) "AUTO" else "MANUAL"
                                    )
                                }
                            } catch (_: Exception) {
                                runOnUiThread { receiverDebugView?.text = "Received an invalid control packet." }
                            }
                        }
                    } catch (_: Exception) {
                    } finally {
                        ControlStateStore.latest = null
                        runOnUiThread { receiverDebugView?.text = "PHONE DISCONNECTED\\nWaiting for control packets…" }
                        try { client.close() } catch (_: Exception) { }
                        runOnUiThread { if (!isFinishing) setStatus("PHONE DISCONNECTED  ·  listening on port $PORT") }
                    }
                }
            } catch (e: Exception) {
                if (serverSocket?.isClosed != true) runOnUiThread { setStatus("Receiver error: ${e.message}") }
            }
        }
    }

    private fun wifiIpAddress(): String = try {
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val raw = wifi.connectionInfo.ipAddress
        if (raw == 0) "Not connected to Wi‑Fi" else listOf(raw and 255, raw shr 8 and 255, raw shr 16 and 255, raw shr 24 and 255).joinToString(".")
    } catch (_: Exception) { "Open Wi‑Fi details to find IP" }

    private fun setStatus(message: String) { statusView?.text = message }

    override fun onSensorChanged(event: SensorEvent) {
        if (role != Role.CONTROLLER) return
        val matrix = FloatArray(9); val orientation = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(matrix, event.values)
        val remapped = FloatArray(9)
        when (windowManager.defaultDisplay.rotation) {
            android.view.Surface.ROTATION_90 -> SensorManager.remapCoordinateSystem(matrix, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, remapped)
            android.view.Surface.ROTATION_180 -> SensorManager.remapCoordinateSystem(matrix, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_MINUS_Y, remapped)
            android.view.Surface.ROTATION_270 -> SensorManager.remapCoordinateSystem(matrix, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, remapped)
            else -> matrix.copyInto(remapped)
        }
        SensorManager.getOrientation(remapped, orientation); currentRoll = orientation[2]
        if (calibrated) {
            var delta = currentRoll - neutralRoll
            if (delta > PI) delta -= (2 * PI).toFloat()
            if (delta < -PI) delta += (2 * PI).toFloat()
            var normalized = (delta * 1.7f).coerceIn(-1f, 1f)
            if (abs(normalized) < 0.035f) normalized = 0f
            steering = steering * 0.72f + normalized * 0.28f
            steerValueView?.text = String.format(java.util.Locale.US, "%+.2f", steering)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onResume() { super.onResume(); if (role == Role.CONTROLLER) rotationSensor?.let { sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) } }
    override fun onPause() { sensorManager?.unregisterListener(this); super.onPause() }
    override fun onDestroy() {
        sender?.cancel(true)
        try { writer?.close() } catch (_: Exception) { }
        try { clientSocket?.close() } catch (_: Exception) { }
        try { serverSocket?.close() } catch (_: Exception) { }
        io.shutdownNow(); super.onDestroy()
    }
}
