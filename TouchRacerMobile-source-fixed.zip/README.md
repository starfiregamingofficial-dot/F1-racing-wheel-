# Touch Racer Mobile

A two-device Android controller prototype for testing phone tilt + pedal controls with a game running on an Android tablet.

- **Phone:** install the APK, choose **PHONE / CONTROLLER**, enter the tablet's Wi-Fi IP, connect, calibrate the neutral phone position, then use the pedals and paddles.
- **Tablet:** install the same APK, choose **TABLET / RECEIVER**, start the receiver, enable the app's Accessibility Service, then open Monoposto.
- Both devices must be on the same private Wi-Fi network or phone hotspot. The receiver listens on TCP port **8765**.

## Build the APK with GitHub Actions

This project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9 and Java 17. The repository workflow at `.github/workflows/build-apk.yml` builds a debug APK whenever code is pushed to `main`/`master`, or when manually started from the Actions tab.

The APK appears as the `TouchRacerMobile-debug-apk` artifact on the completed workflow run.

## Important first-test setup

The touch map is in `app/src/main/java/com/touchracermobile/TouchBridgeService.kt`, in the `STEER_*`, `THROTTLE_*`, `BRAKE_*`, `GEAR_*`, `DRS_*`, and `ERS_*` constants. They are **percentage-of-screen defaults**, not verified Monoposto coordinates. Change them to match the game's actual landscape HUD. Coordinates are fractions from 0.0 (left/top) to 1.0 (right/bottom).

The tablet Accessibility Service must be enabled by the user. It can simulate touchscreen input, so enable it only for this app while testing. Keep the devices on a private hotspot/Wi-Fi; the local TCP connection is not encrypted and has no login.

## Known prototype limits

- This is a device-test prototype, not a certified or finished racing wheel.
- The touch positions must be calibrated against the current game HUD. If Monoposto uses a different steering-control style (for example, a fixed on-screen wheel rather than a drag zone), the steering mapping will need adjustment.
- Actual RPM, speed, lap timing and telemetry are not read from Monoposto; the app intentionally does not display invented telemetry.
- Android Accessibility gesture continuation can still be interrupted by Android or the game. If that happens, controls may release and need reconnecting.
- Test at low speed / in a safe practice session first. Do not rely on this controller for a competitive race until it has been validated on both devices.

## App architecture

`MainActivity.kt` contains the two device modes, controller dashboard, sensor steering, and local TCP server/client. `ControlState.kt` parses incoming control packets. `TouchBridgeService.kt` maintains continued multi-touch contacts for steering and held pedals, and sends short taps for gear/DRS/ERS actions.
