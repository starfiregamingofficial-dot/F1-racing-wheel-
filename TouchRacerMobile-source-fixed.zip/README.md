# Touch Racer Mobile 2.0

A two-device Android racing controller prototype for Monoposto-style games.

## Version 2.0 controller updates
- Full-height **BRAKE** pedal on the left.
- Full-height **THROTTLE** pedal on the right.
- Gyroscope steering with a neutral-position calibration button.
- **AUTO GEAR / MANUAL GEAR** toggle saved on the phone.
- Manual UP/DOWN buttons are ignored while AUTO GEAR is selected.
- DRS and ERS toggles.
- Up to three extra quick buttons. Add a custom label and map each one to DRS, ERS, GEAR UP, or GEAR DOWN. Long-press an extra button to remove it.
- New red/black launcher icon.

## Build
The repository's GitHub Actions workflow should extract this ZIP into `project/` and run `gradle assembleDebug` from that directory. The debug APK is uploaded as an Actions artifact.

## Two-device setup
1. Install this APK on both Android devices.
2. Connect both devices to the same private Wi-Fi network or phone hotspot.
3. On the tablet, open the app, choose **TABLET / RECEIVER**, then start the receiver. Note the displayed IP address.
4. Enable the app's Accessibility Service on the tablet only if you understand and accept that it can dispatch touch gestures to the screen.
5. On the phone, choose **PHONE / CONTROLLER**, enter the tablet IP and connect.
6. Calibrate gyro steering with the phone held in its normal landscape driving position.
7. Open the game on the tablet and test at low speed first.

## Important limitations
- AUTO GEAR is a controller-side mode: it disables this app's manual gear commands. It does **not** change the game's own automatic-transmission setting unless the game exposes a compatible on-screen control.
- Tablet touch coordinates in `TouchBridgeService.kt` are initial approximations. They must be aligned to the game's actual HUD positions before driving.
- Accessibility gesture dispatch is subject to Android/game limitations. Multi-touch continuity and latency must be tested on the actual devices.
- The receiver is a prototype TCP service for a trusted private network. It has no encryption or pairing authentication. Do not expose it to public networks.
- This is an unofficial community controller prototype, not affiliated with the game developer.


## Monoposto HUD calibration update

This revision uses the supplied 1536x864 Monoposto screenshot as a starting reference.
- Throttle touch: lower-right pedal zone (93% width, 91% height).
- Brake touch: lower-left pedal zone (7% width, 91% height).
- Continued accessibility strokes now start the continuation segment after the prior 80 ms segment, rather than restarting at time zero.

These are initial coordinates, not a verified game fix. Android display insets, HUD scaling, and the selected Monoposto control mode can shift the actual hit areas. Test with the car stationary in practice mode.
